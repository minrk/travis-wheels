version_info = (5, 1, 5)
__version__ = '.'.join(map(str, version_info))
__frontend_version__ = '~1.1.2'
