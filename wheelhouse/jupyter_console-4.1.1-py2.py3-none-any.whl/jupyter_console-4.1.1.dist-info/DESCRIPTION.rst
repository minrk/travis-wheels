An IPython-like terminal frontend for Jupyter kernels in any language.


