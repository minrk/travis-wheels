.. image:: https://img.shields.io/pypi/v/widgetsnbextension.svg
   :target: https://pypi.python.org/pypi/widgetsnbextension/
   :alt: Version Number

.. image:: https://img.shields.io/pypi/dm/widgetsnbextension.svg
   :target: https://pypi.python.org/pypi/widgetsnbextension/
   :alt: Number of PyPI downloads

Interactive HTML Widgets
========================

Interactive HTML widgets for Jupyter notebooks.

Usage
=====

Install the corresponding package for your kernel.  i.e. Python users would also
install `ipywidgets`.  Refer to that package's documentation for usage 
instructions.


