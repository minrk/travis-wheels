from __future__ import absolute_import

from warnings import warn

warn("IPython.utils.traitlets has moved to a top-level traitlets package.")

from traitlets import *
