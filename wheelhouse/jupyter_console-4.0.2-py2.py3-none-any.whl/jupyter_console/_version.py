version_info = (4, 0, 2)
__version__ = '.'.join(map(str, version_info))
