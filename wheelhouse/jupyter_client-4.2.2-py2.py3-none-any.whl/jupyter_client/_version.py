version_info = (4, 2, 2)
__version__ = '.'.join(map(str, version_info))

protocol_version_info = (5, 0)
protocol_version = "%i.%i" % protocol_version_info
